﻿using HMSDAL;
using HMSEntity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSBLL
{
    public class PatientBLL
    {

        private static bool ValidatePatient(Patient patient)
        {

            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientID <= 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Invalid Patient ID");

            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Name Required");

            }
            if (patient.Phone.Length < 10)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validPatient == false)
                throw new PatientException(sb.ToString());
            return validPatient;
        }

        public static bool AddPatientBL(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientAdded = patientDAL.AddPatientDAL(newPatient);
                }
            }
            catch (PatientException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        public static List<Patient> GetAllPatientsBL()
        {
            List<Patient> patientList = null;
            try
            {
                PatientDAL patientDAL = new PatientDAL();
                patientList = patientDAL.GetAllPatientsDAL();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }




        public static bool DeletePatientBL(int deletePatientID)
        {
            bool patientDeleted = false;
            try
            {
                if (deletePatientID > 0)
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientDeleted = patientDAL.DeletePatientDAL(deletePatientID);
                }
                else
                {
                    throw new PatientException("Invalid Patient ID");
                }
            }
            catch (PatientException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientDeleted;
        }

        public static Patient SearchPatientBL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                PatientDAL patientDAL = new PatientDAL();
                searchPatient = patientDAL.SearchPatientDAL(searchPatientID);
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static bool UpdatePatientBL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientUpdated = patientDAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (PatientException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }
    }
}
