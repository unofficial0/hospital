﻿using HMSEntity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSDAL
{
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();
        public bool AddPatientDAL(Patient newPatient)
        {
            bool patinetAdded = false;
            try
            {

                patientList.Add(newPatient);
                patinetAdded = true;


            }
            catch (Exception ex)
            {
                throw new PatientException(ex.Message);
            }
            return patinetAdded;

        }

        public List<Patient> GetAllPatientsDAL()
        {
            return patientList;
        }

        public bool DeletePatientDAL(int deletepatientID)
        {
            bool patientDeleted = false;
            try
            {
                Patient patient = patientList.Find(p => p.PatientID == deletepatientID);
                int index = patientList.IndexOf(patient);
                patientList.RemoveAt(index);
                patientDeleted = true;
            }
            catch (Exception ex)
            {
                throw new PatientException(ex.Message);
            }
            return patientDeleted;

        }


        public Patient SearchPatientDAL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = patientList.Find(p => p.PatientID == searchPatientID);
            }
            catch (Exception ex)
            {
                throw new PatientException(ex.Message);
            }
            return searchPatient;
        }

        public bool UpdatePatientDAL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                Patient patient = patientList.Find(p => p.PatientID == updatePatient.PatientID);
                int index = patientList.IndexOf(patient);
                patientList[index] = updatePatient;
                patientUpdated = true;
            }
            catch (Exception ex)
            {
                throw new PatientException(ex.Message);
            }
            return patientUpdated;
        }
    }
}
